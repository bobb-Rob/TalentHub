# Portfolio Project: Setup & Development Guide

## Quick Start

### Prerequisites
- Node.js 16+ and npm 8+
- Git installed
- Code editor (VS Code recommended)
- GitHub account (for repository)

### Project Structure

```
portfolio/
├── public/
│   ├── index.html
│   └── images/
│       ├── projects/          # Project thumbnails
│       │   ├── sentiment-analysis.jpg
│       │   ├── ml-model.jpg
│       │   └── ...
│       └── avatar.jpg
├── src/
│   ├── components/
│   │   ├── common/
│   │   │   ├── Navbar.jsx
│   │   │   ├── Footer.jsx
│   │   │   └── Button.jsx
│   │   ├── sections/
│   │   │   ├── Hero.jsx
│   │   │   ├── Projects.jsx
│   │   │   ├── About.jsx
│   │   │   └── Contact.jsx
│   │   └── projects/
│   │       └── ProjectCard.jsx
│   ├── data/
│   │   ├── projects.json
│   │   └── skills.json
│   ├── store/
│   │   └── store.js            # Zustand store
│   ├── styles/
│   │   ├── globals.css
│   │   └── tailwind.config.js
│   ├── App.jsx
│   ├── App.css
│   └── index.jsx
├── .env.example
├── package.json
├── tailwind.config.js
├── postcss.config.js
└── README.md
```

---

## Installation Steps

### 1. Create Project

```bash
npx create-react-app portfolio
cd portfolio
```

### 2. Install Dependencies

```bash
npm install react-router-dom tailwindcss zustand react-icons emailjs-com axios
npm install -D autoprefixer postcss
```

### 3. Configure Tailwind

```bash
npx tailwindcss init -p
```

Update `tailwind.config.js`:

```js
export default {
  content: [
    "./index.html",
    "./src/**/*.{js,jsx}",
  ],
  theme: {
    extend: {
      colors: {
        primary: "#1A202C",     // Navy
        accent: "#14B8A6",      // Teal
        danger: "#EF4444",      // Red
        success: "#10B981",     // Green
      },
      fontFamily: {
        display: ["Poppins", "sans-serif"],
        body: ["Inter", "sans-serif"],
      },
    },
  },
  plugins: [],
};
```

### 4. Set Environment Variables

Create `.env` file in project root:

```env
REACT_APP_EMAILJS_SERVICE_ID=your_emailjs_service_id
REACT_APP_EMAILJS_TEMPLATE_ID=your_emailjs_template_id
REACT_APP_EMAILJS_PUBLIC_KEY=your_emailjs_public_key
```

### 5. Get EmailJS Credentials

1. Visit [emailjs.com](https://www.emailjs.com)
2. Sign up (free tier: 200 emails/month)
3. Create email service (Gmail recommended)
4. Create email template
5. Copy Service ID, Template ID, Public Key to `.env`

---

## Data Files Setup

### `src/data/projects.json`

```json
{
  "projects": [
    {
      "id": "project-001",
      "title": "Cross-Domain Sentiment Analysis",
      "description": "ML framework for e-commerce sentiment analysis using supervised contrastive learning",
      "thumbnail": "/images/projects/sentiment-analysis.jpg",
      "technologies": ["Python", "RoBERTa", "PyTorch"],
      "liveUrl": "https://your-demo.com",
      "githubUrl": "https://github.com/olufems/sentiment-analysis",
      "featured": true,
      "completionDate": "2026-05-15"
    },
    {
      "id": "project-002",
      "title": "Propensity & Affinity ML Models",
      "description": "Recommendation system using propensity modeling and collaborative filtering",
      "thumbnail": "/images/projects/recommendation-system.jpg",
      "technologies": ["LightFM", "Python", "Scikit-learn"],
      "liveUrl": "https://your-demo2.com",
      "githubUrl": "https://github.com/olufems/recommendation-system",
      "featured": true,
      "completionDate": "2026-04-10"
    }
  ]
}
```

### `src/data/skills.json`

```json
{
  "skillCategories": [
    {
      "category": "Programming Languages",
      "skills": [
        { "name": "Python", "proficiency": "Expert", "years": 4 },
        { "name": "JavaScript", "proficiency": "Proficient", "years": 3 },
        { "name": "SQL", "proficiency": "Proficient", "years": 2 }
      ]
    },
    {
      "category": "ML & AI",
      "skills": [
        { "name": "NLP", "proficiency": "Expert", "years": 3 },
        { "name": "Deep Learning", "proficiency": "Proficient", "years": 2 }
      ]
    },
    {
      "category": "Web Technologies",
      "skills": [
        { "name": "React", "proficiency": "Proficient", "years": 2 },
        { "name": "Node.js", "proficiency": "Proficient", "years": 2 }
      ]
    },
    {
      "category": "Databases",
      "skills": [
        { "name": "PostgreSQL", "proficiency": "Proficient", "years": 2 },
        { "name": "MongoDB", "proficiency": "Proficient", "years": 1 }
      ]
    }
  ]
}
```

---

## Component Templates

### `src/components/common/Navbar.jsx`

```jsx
import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import { HiMenu, HiX } from 'react-icons/hi';

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);

  const navLinks = [
    { label: 'Home', href: '#home' },
    { label: 'Projects', href: '#projects' },
    { label: 'About', href: '#about' },
    { label: 'Contact', href: '#contact' },
  ];

  return (
    <nav className="sticky top-0 bg-white shadow-md z-50">
      <div className="max-w-6xl mx-auto px-4 py-4 flex justify-between items-center">
        <Link to="/" className="text-2xl font-bold text-primary">Olufems</Link>
        
        {/* Desktop Menu */}
        <div className="hidden md:flex gap-8">
          {navLinks.map(link => (
            <a key={link.href} href={link.href} className="text-gray-700 hover:text-accent transition">
              {link.label}
            </a>
          ))}
        </div>

        {/* Mobile Menu Button */}
        <button className="md:hidden" onClick={() => setIsOpen(!isOpen)}>
          {isOpen ? <HiX size={24} /> : <HiMenu size={24} />}
        </button>

        {/* Mobile Menu */}
        {isOpen && (
          <div className="absolute top-16 left-0 right-0 bg-white shadow-lg md:hidden">
            {navLinks.map(link => (
              <a 
                key={link.href} 
                href={link.href} 
                className="block px-4 py-2 hover:bg-gray-100"
                onClick={() => setIsOpen(false)}
              >
                {link.label}
              </a>
            ))}
          </div>
        )}
      </div>
    </nav>
  );
}
```

### `src/components/sections/Hero.jsx`

```jsx
import React from 'react';
import { HiArrowRight } from 'react-icons/hi';

export function Hero() {
  return (
    <section id="home" className="min-h-screen bg-gradient-to-br from-primary to-primary-dark flex items-center">
      <div className="max-w-6xl mx-auto px-4 w-full">
        <div className="grid md:grid-cols-2 gap-8 items-center">
          {/* Text Content */}
          <div className="text-white">
            <h1 className="text-5xl md:text-6xl font-bold font-display mb-4">
              Hi, I'm Olufems
            </h1>
            <p className="text-xl text-gray-300 mb-6 font-body max-w-lg">
              Full-stack ML engineer focused on NLP and data-efficient AI systems. 
              Transforming complex problems into elegant, scalable solutions.
            </p>
            <div className="flex gap-4">
              <a 
                href="#projects" 
                className="bg-accent text-white px-6 py-3 rounded-lg hover:scale-105 transition flex items-center gap-2"
              >
                View My Work <HiArrowRight />
              </a>
              <a 
                href="/resume.pdf" 
                className="border-2 border-white text-white px-6 py-3 rounded-lg hover:bg-white hover:text-primary transition"
              >
                Download CV
              </a>
            </div>
          </div>

          {/* Avatar */}
          <div className="hidden md:flex justify-center">
            <img 
              src="/images/avatar.jpg" 
              alt="Olufems" 
              className="w-80 h-80 rounded-full object-cover border-4 border-accent shadow-2xl"
            />
          </div>
        </div>
      </div>
    </section>
  );
}
```

### `src/components/sections/Projects.jsx`

```jsx
import React, { useState, useMemo } from 'react';
import projectsData from '../../data/projects.json';
import { ProjectCard } from '../projects/ProjectCard';

export function Projects() {
  const [selectedTech, setSelectedTech] = useState(null);

  // Extract all unique technologies
  const allTechs = useMemo(() => {
    const techs = new Set();
    projectsData.projects.forEach(p => p.technologies.forEach(t => techs.add(t)));
    return Array.from(techs).sort();
  }, []);

  // Filter projects by selected technology
  const filteredProjects = useMemo(() => {
    if (!selectedTech) return projectsData.projects;
    return projectsData.projects.filter(p => p.technologies.includes(selectedTech));
  }, [selectedTech]);

  return (
    <section id="projects" className="py-20 bg-gray-50">
      <div className="max-w-6xl mx-auto px-4">
        <h2 className="text-4xl font-bold font-display mb-4 text-primary">Featured Work</h2>
        <p className="text-gray-600 mb-12 text-lg">
          Showcasing key projects that demonstrate my expertise in ML, NLP, and full-stack development.
        </p>

        {/* Tech Filter */}
        <div className="mb-12 flex flex-wrap gap-2">
          <button
            onClick={() => setSelectedTech(null)}
            className={`px-4 py-2 rounded-full transition ${
              selectedTech === null 
                ? 'bg-accent text-white' 
                : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-accent'
            }`}
          >
            All
          </button>
          {allTechs.map(tech => (
            <button
              key={tech}
              onClick={() => setSelectedTech(tech)}
              className={`px-4 py-2 rounded-full transition ${
                selectedTech === tech 
                  ? 'bg-accent text-white' 
                  : 'bg-white border-2 border-gray-300 text-gray-700 hover:border-accent'
              }`}
            >
              {tech}
            </button>
          ))}
        </div>

        {/* Projects Grid */}
        <div className="grid md:grid-cols-3 gap-8">
          {filteredProjects.map(project => (
            <ProjectCard key={project.id} project={project} />
          ))}
        </div>
      </div>
    </section>
  );
}
```

### `src/components/projects/ProjectCard.jsx`

```jsx
import React, { useState } from 'react';
import { HiExternalLink, HiCode } from 'react-icons/hi';

export function ProjectCard({ project }) {
  const [isHovered, setIsHovered] = useState(false);

  return (
    <div 
      className={`bg-white rounded-lg overflow-hidden shadow-md transition-all duration-300 ${
        isHovered ? 'scale-105 shadow-2xl' : ''
      }`}
      onMouseEnter={() => setIsHovered(true)}
      onMouseLeave={() => setIsHovered(false)}
    >
      {/* Thumbnail */}
      <div className="overflow-hidden h-48 bg-gray-200">
        <img 
          src={project.thumbnail} 
          alt={project.title}
          className="w-full h-full object-cover"
          loading="lazy"
        />
      </div>

      {/* Content */}
      <div className="p-6">
        <h3 className="text-xl font-bold text-primary mb-2">{project.title}</h3>
        <p className="text-gray-600 text-sm mb-4">{project.description}</p>

        {/* Tech Tags */}
        <div className="flex flex-wrap gap-2 mb-4">
          {project.technologies.map(tech => (
            <span 
              key={tech}
              className="text-xs bg-accent/10 text-accent px-3 py-1 rounded-full"
            >
              {tech}
            </span>
          ))}
        </div>

        {/* Action Buttons */}
        <div className="flex gap-3">
          <a 
            href={project.liveUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex-1 bg-accent text-white py-2 rounded text-center hover:bg-accent/90 transition flex items-center justify-center gap-2"
          >
            Live Demo <HiExternalLink />
          </a>
          <a 
            href={project.githubUrl} 
            target="_blank" 
            rel="noopener noreferrer"
            className="flex-1 border-2 border-accent text-accent py-2 rounded text-center hover:bg-accent/10 transition flex items-center justify-center gap-2"
          >
            Code <HiCode />
          </a>
        </div>
      </div>
    </div>
  );
}
```

### `src/components/sections/Contact.jsx`

```jsx
import React, { useState } from 'react';
import emailjs from 'emailjs-com';
import { HiCheckCircle, HiExclamationCircle } from 'react-icons/hi';

export function Contact() {
  const [formData, setFormData] = useState({
    name: '',
    email: '',
    subject: '',
    message: ''
  });

  const [errors, setErrors] = useState({});
  const [status, setStatus] = useState(null); // 'loading', 'success', 'error'
  const [message, setMessage] = useState('');

  // Validation rules
  const validateForm = () => {
    const newErrors = {};
    if (!formData.name.trim() || formData.name.length < 2) newErrors.name = 'Name required (min 2 chars)';
    if (!formData.email.match(/^[^\s@]+@[^\s@]+\.[^\s@]+$/)) newErrors.email = 'Valid email required';
    if (!formData.subject.trim() || formData.subject.length < 5) newErrors.subject = 'Subject required (min 5 chars)';
    if (!formData.message.trim() || formData.message.length < 20) newErrors.message = 'Message required (min 20 chars)';
    return newErrors;
  };

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({ ...prev, [name]: value }));
    // Clear error for this field when user starts typing
    if (errors[name]) setErrors(prev => ({ ...prev, [name]: '' }));
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    // Validate
    const newErrors = validateForm();
    if (Object.keys(newErrors).length > 0) {
      setErrors(newErrors);
      return;
    }

    setStatus('loading');

    try {
      await emailjs.send(
        process.env.REACT_APP_EMAILJS_SERVICE_ID,
        process.env.REACT_APP_EMAILJS_TEMPLATE_ID,
        {
          to_email: 'your-email@example.com', // Your email
          from_name: formData.name,
          from_email: formData.email,
          subject: formData.subject,
          message: formData.message,
        },
        process.env.REACT_APP_EMAILJS_PUBLIC_KEY
      );

      setStatus('success');
      setMessage('Message sent! I\'ll get back to you soon.');
      setFormData({ name: '', email: '', subject: '', message: '' });
      
      // Clear success message after 5 seconds
      setTimeout(() => setStatus(null), 5000);
    } catch (error) {
      setStatus('error');
      setMessage('Failed to send. Please try again or email me directly.');
    }
  };

  return (
    <section id="contact" className="py-20 bg-white">
      <div className="max-w-2xl mx-auto px-4">
        <h2 className="text-4xl font-bold font-display mb-4 text-primary">Get In Touch</h2>
        <p className="text-gray-600 mb-12 text-lg">
          Have a project in mind or want to discuss collaboration? Send me a message!
        </p>

        <form onSubmit={handleSubmit} className="space-y-6">
          {/* Name */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Name</label>
            <input
              type="text"
              name="name"
              value={formData.name}
              onChange={handleChange}
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent ${
                errors.name ? 'border-danger' : 'border-gray-300'
              }`}
              placeholder="Your name"
            />
            {errors.name && <p className="text-danger text-sm mt-1">{errors.name}</p>}
          </div>

          {/* Email */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Email</label>
            <input
              type="email"
              name="email"
              value={formData.email}
              onChange={handleChange}
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent ${
                errors.email ? 'border-danger' : 'border-gray-300'
              }`}
              placeholder="your.email@example.com"
            />
            {errors.email && <p className="text-danger text-sm mt-1">{errors.email}</p>}
          </div>

          {/* Subject */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Subject</label>
            <input
              type="text"
              name="subject"
              value={formData.subject}
              onChange={handleChange}
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent ${
                errors.subject ? 'border-danger' : 'border-gray-300'
              }`}
              placeholder="Project inquiry"
            />
            {errors.subject && <p className="text-danger text-sm mt-1">{errors.subject}</p>}
          </div>

          {/* Message */}
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-2">Message</label>
            <textarea
              name="message"
              value={formData.message}
              onChange={handleChange}
              rows="5"
              className={`w-full px-4 py-2 border rounded-lg focus:outline-none focus:ring-2 focus:ring-accent ${
                errors.message ? 'border-danger' : 'border-gray-300'
              }`}
              placeholder="Tell me about your project..."
            />
            {errors.message && <p className="text-danger text-sm mt-1">{errors.message}</p>}
          </div>

          {/* Submit Button */}
          <button
            type="submit"
            disabled={status === 'loading'}
            className="w-full bg-accent text-white py-3 rounded-lg hover:bg-accent/90 transition disabled:opacity-50"
          >
            {status === 'loading' ? 'Sending...' : 'Send Message'}
          </button>

          {/* Status Messages */}
          {status === 'success' && (
            <div className="flex items-center gap-2 text-success bg-success/10 p-4 rounded-lg">
              <HiCheckCircle size={20} />
              <span>{message}</span>
            </div>
          )}
          {status === 'error' && (
            <div className="flex items-center gap-2 text-danger bg-danger/10 p-4 rounded-lg">
              <HiExclamationCircle size={20} />
              <span>{message}</span>
            </div>
          )}
        </form>
      </div>
    </section>
  );
}
```

---

## App Integration

### `src/App.jsx`

```jsx
import React from 'react';
import { BrowserRouter as Router } from 'react-router-dom';
import { Navbar } from './components/common/Navbar';
import { Footer } from './components/common/Footer';
import { Hero } from './components/sections/Hero';
import { Projects } from './components/sections/Projects';
import { About } from './components/sections/About';
import { Contact } from './components/sections/Contact';

function App() {
  return (
    <Router>
      <Navbar />
      <main>
        <Hero />
        <Projects />
        <About />
        <Contact />
      </main>
      <Footer />
    </Router>
  );
}

export default App;
```

---

## Running the Project

```bash
# Start development server
npm start

# Build for production
npm run build

# Deploy to Vercel
npm install -g vercel
vercel
```

---

## Deployment

### Option 1: Vercel (Recommended)

```bash
npm install -g vercel
vercel
```

### Option 2: Netlify

```bash
npm run build
# Upload 'build' folder to Netlify, or:
npm install -g netlify-cli
netlify deploy --prod --dir=build
```

---

## Next Steps

1. ✅ Install dependencies (Section 1-3)
2. ✅ Set up data files (Section 4-5)
3. ✅ Implement components (Section 6-7)
4. ✅ Configure EmailJS
5. ✅ Test locally (`npm start`)
6. ✅ Deploy (`vercel` or `netlify`)

**You're ready to build!** 🚀
