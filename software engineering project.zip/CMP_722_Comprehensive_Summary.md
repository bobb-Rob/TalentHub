# CMP 722: Software Engineering Principles
## Comprehensive Feedback & Summary of Class Discussions

**Course:** CMP 722 - Software Engineering Principles  
**Institution:** Anchor University Lagos (Postgraduate Programme)  
**Instructor:** Dr. Oluwasefunmi Arogundade  
**Dates Covered:** Wednesday, June 3 & June 10, 2026  

---

## Overview

The CMP 722 course focuses on fundamental principles of software engineering as applied to real-world project development. The transcript materials reveal two consecutive class sessions that built progressively from foundational process concepts to advanced process models and incremental delivery strategies. The instructor emphasized core competencies that students must internalize, stressing that regardless of the software development model chosen, all systems must pass through four canonical process activities.

---

## Core Academic Content Covered

### 1. **Software Process Models & Four Canonical Activities**

#### Key Concept
The instructor repeatedly emphasized that all software systems, regardless of their development methodology, must pass through **four fundamental process activities**:

1. **Specification** – Defining what the system will do
2. **Design & Implementation** – Translating requirements into architecture and code
3. **Validation** – Ensuring customer needs are met and conformance to specification
4. **Evolution** – Maintaining and updating the system in response to changing business needs

#### Instructor's Key Message
- These four activities are non-negotiable and form the backbone of any software project
- Different models (Waterfall, Agile, Spiral) differ only in *how* they sequence or iterate through these activities, not in *whether* they include them
- Students were directed to ensure these activities are "at their fingertips" for the course

#### Classroom Engagement Issue
- Students struggled to articulate these four activities when prompted, initially suggesting model names (Waterfall) rather than process activities
- The instructor had to redirect the class multiple times, indicating a gap in foundational understanding that needed reinforcement

---

### 2. **Software Process Models Compared**

The instructor introduced several software development models and their characteristics:

#### **Waterfall (Plan-Driven) Model**
- Sequential execution of activities
- Activities proceed one after another in a linear fashion
- All four core activities are completed in order: specification → design/implementation → validation → evolution
- Best suited for well-defined requirements upfront

#### **Incremental (Use-Oriented / Component-Based) Model**
- Multiple development activities run concurrently
- Produces intermediate versions and final versions in parallel
- Component analysis is a critical first step:
  - Understand component content and prior uses
  - Modify requirements to fit existing components (if necessary)
  - Design, develop, integrate, and validate using proven components
- Modern standard for business system development due to component reuse

#### **Spiral Model (Boehm's Approach)**
- Process organized as concentric spirals rather than linear sequences
- Each loop in the spiral represents a development phase
- No fixed phases; loops chosen based on requirements
- **Risk assessment & resolution integrated at every loop** (key differentiator)
- Incorporates prototype development with explicit risk management
- Phases: Requirements Planning → Risk Analysis → Software Requirements → Prototype → Product Design → Integration/Test → Detailed Design → Service Deployment

#### **Rational Unified Process (RUP)**
- Modern process model derived from UML work
- Combines aspects of Waterfall, Incremental, and Spiral models
- Organized in four distinct phases:
  1. **Inception** – Establish business case for the system
  2. **Elaboration** – Develop understanding of problem domain and system architecture
  3. **Construction** – Execute system design, programming, and testing
  4. **Transition** – Deploy and hand over to operational support

---

### 3. **Component-Based (Use-Oriented) Software Engineering**

#### Reuse as Industry Standard
The instructor asserted that **reuse is now the standard approach** for building business systems. Instead of building components from scratch, modern development leverages:
- Standard libraries provided by programming languages
- Tested and proven COTS (Commercial Off-The-Shelf) components
- Components tailored for specific domains (healthcare, education, e-commerce)

#### Component Selection & Analysis Workflow
Unlike traditional waterfall specification, component-based development follows this sequence:

1. **Component Analysis** – Understand the content, capabilities, and prior uses of selected components
2. **Requirement Alignment** – If components don't perfectly fit initial requirements, modify requirements to align with component capabilities
3. **Design** – Design the system architecture incorporating selected components (reuse-oriented)
4. **Development & Integration** – Implement and integrate components into the system
5. **Validation** – Test the assembled system

#### Building Block Analogy
The instructor used a construction analogy: just as builders don't manufacture custom bricks for each house when proven, tested bricks are available on the market, software developers reuse proven components rather than reinventing the wheel.

#### Clarification on Reuse vs. Refactoring
A student asked whether reuse meant refactoring (extracting functions from one application to use in another). The instructor clarified that reuse refers to leveraging **existing, tested components**—not extracting and adapting code from completed systems.

---

### 4. **Prototyping & Its Economic Benefits**

#### Cost Reduction Through Prototyping
The instructor explained that prototyping significantly reduces both development costs and effort:

**Without Prototyping (High Risk):**
- Develop complete system end-to-end
- Deliver to customer
- If requirements unmet → entire project may need to be abandoned or heavily reworked
- Result: Double cost and wasted effort

**With Prototyping (Feedback-Driven):**
- Develop small, focused version early
- Gather customer feedback before final development
- Iterate based on feedback
- Result: Cost and effort reduced through early course correction

#### Prototyping Process
1. Establish prototype objectives
2. Create prototype plan
3. Define prototype functionality (often prioritizing customer-critical features)
4. Develop the prototype
5. Evaluate with customers
6. Re-analyze objectives and functionality based on feedback
7. Iterate to next prototype version

#### Rapid Prototyping Strategy
- Focus prototype functionality on **highest-priority customer requirements**
- Omit lower-priority features initially
- Deliver what matters most to customers first
- Receive enthusiastic feedback and actionable improvements
- Scale up with additional features in subsequent iterations

#### Throw-Away vs. Incremental Prototypes
- **Throw-Away Prototypes:** Discarded after requirements elicitation; not suitable as production system basis due to lack of documentation and code degradation through rapid changes
- **Incremental Prototypes:** Serve as foundation for production system; prioritize requirements and deploy early increments for user evaluation

---

### 5. **Incremental Delivery & Agile Principles**

#### Advantages of Incremental Delivery
1. **Customer Value Delivered Early** – System functionality available with each increment, rather than waiting for final delivery
2. **Reduced Overall Project Risk** – Early delivery of core features catches issues before full project completion
3. **Prioritized Testing** – Highest-priority services/functionality receive the most testing across all increments (tested in increment 1, re-tested in increments 2, 3, etc.)
4. **Realistic User Evaluation** – Real users evaluate practical use of the software, not theoretical specifications

#### Incremental Delivery Process
1. Define user requirements
2. Prioritize and assign requirements to specific increments
3. Design system architecture
4. Develop system increments
5. Validate each increment with users
6. Integrate validated increments
7. Validate complete system
8. Deploy increments as they complete
9. If system incomplete, return to development of additional increments
10. Once complete, deploy final system and conduct final validation

#### Customer Priority Focus
A key insight emerged during classroom discussion: when developing incrementally, **highest-priority customer requirements receive disproportionate testing attention**. For example, if a customer identifies 4 critical features in increment 1:
- Those 4 features are tested in increment 1 delivery
- When increments 2 and 3 add new features, all previous features (including the original 4) are re-tested
- This ensures customer-critical functionality is robust across all versions

---

### 6. **Requirement Engineering & Verification vs. Validation**

#### Requirement Engineering Breakdown
The instructor outlined requirement engineering phases:
1. **Feasibility Study** – Assess technical and economic feasibility
2. **Elicitation & Analysis** – Gather requirements through questionnaires, interviews, document review
3. **Specification** – Decompose high-level requests into detailed, implementable functions
4. **Validation** – Confirm requirements meet customer needs

#### Verification vs. Validation
- **Verification:** Ensures the software conforms to its specification (Are we building it right?)
- **Validation:** Ensures the software meets customer/user needs (Are we building the right thing?)

#### Testing Stages
1. **Unit Testing** – Test individual components
2. **Component/Integration Testing** – Test combined components
3. **System Testing** – Test complete system functionality
4. **Acceptance Testing** – Customer/user acceptance (critical stage)

---

### 7. **Design Activities & Database Design**

#### Four Key Design Deliverables
1. **System Architecture** – Overall structural organization of components
2. **Database Design** – Entity-relationship modeling and schema design
3. **Interface/UI-UX Design** – User interaction design and visual design
4. **Component Specification** – Detailed specification of individual components

#### Database Design Example
The instructor used a school management system to illustrate design approach:
- **Entities:** Students, Lecturers, Courses
- **Attributes:** Student ID, Name, Program; Lecturer ID, Qualifications; Course Code, Units
- **Test Data:** Instances of entities used for querying the designed database

#### Clarification on "Data" in Design Context
A student asked for clarification on the term "data" in the design model. The instructor explained that "data" refers to requirement-derived entities and attributes—not test data. Test data are instances/examples used later to verify the database works correctly.

---

## Classroom Dynamics & Engagement

### Positive Aspects
- **Clear Progression:** The instructor built from foundational concepts (four activities) to advanced models (Spiral, RUP)
- **Real-World Application:** Examples linked to student projects, emphasizing practical relevance
- **Iterative Clarification:** When students misunderstood concepts (e.g., Waterfall as an activity vs. a model), the instructor redirected effectively
- **Peer Learning:** Discussions encouraged students to defend their reasoning and learn from corrections

### Challenges Observed
1. **Initial Unresponsiveness:** Students were reluctant to answer questions in the first session, prompting the instructor to emphasize participation expectations
2. **Conceptual Gaps:** Students confused process *models* with process *activities*, indicating foundational knowledge needs reinforcement
3. **Technical Clarifications Needed:** Questions about refactoring vs. reuse and the meaning of "data" in design suggest students benefit from concrete examples
4. **Audio/Connectivity Issues:** Internet delays and participant availability issues disrupted flow (noted in June 10 session)

---

## Administrative & Logistical Items

### Project Work Requirements
- **Formation:** Project groups formed; instructor (Oluwasefunmi Arogundade) to review and potentially assign topics if groups don't select
- **Deliverables:** Groups must apply architectural, interface, component, and database design activities to their individual projects
- **Skills Development:** Students directed to learn/refresh UI/UX skills and use Figma for interface design
- **Topic Submission:** Groups to submit project topics and full member lists for review

### Research Proposal Deadlines (Critical)
- **Proposal Submission:** June 20/28 (date clarification needed)
- **Defense Date:** June 26
- **Possible Extension:** July 3 (contingent on progress; no formal request yet)
- **Note:** Students deliberating on extension timing; decision pending clarity on individual progress

### Administrative Coordination
- **Attendance Tracking:** Dean-mandated attendance sheet to be brought by Timothy Seyinde for student signatures
- **Library Access:** Significant concern raised regarding PG student library registration and access to required materials
  - Librarian reportedly holds required materials
  - Students planning coordinated campus visit next week to resolve registration through proper channels
  - Recommendation: Contact librarian directly for status update

### Teaching Materials & Tools
- **Course Materials:** PDF provided to students; PowerPoint slides distributed for process model lectures
- **AI Tools:** Oluwafemi Abiona testing Google Docs "AI Insights" add-on for class note summarization; agreed to share with group
- **AI in Research Training:** Timothy Seyinde received invitation to training on "AI in Research Work" and offered to share details with interested classmates
- **Introduction Reading:** Students directed to re-read prior week's introduction to strengthen understanding of software engineering economic benefits

---

## Key Insights & Recommendations

### 1. **Mastery of Four Core Activities is Essential**
- All students should memorize and be able to articulate the four core process activities
- Connect each activity to their specific project work
- Understand how different models sequence these activities differently

### 2. **Reuse is the Modern Standard**
- Students should think about component selection and adaptation early in their projects
- Analyze existing solutions before "building from scratch"
- Modify requirements pragmatically to leverage proven components

### 3. **Risk & Customer Feedback are Central**
- Prototyping and incremental delivery embed customer feedback loops early
- Spiral model makes risk assessment explicit at each phase
- Highest-priority features should receive rigorous testing across all increments

### 4. **Process Model Selection Matters**
- Waterfall suits projects with well-defined, stable requirements
- Incremental/Agile suits evolving requirements and customer involvement
- Spiral suits high-risk, complex projects requiring explicit risk management
- RUP combines benefits of all three—understand trade-offs for your project

### 5. **Design Encompasses More Than Code**
- Architecture, database, UI/UX, and components are distinct design deliverables
- Database design (entity-relationship modeling) is a required deliverable, not optional
- UI/UX design increasingly important—Figma skills recommended

### 6. **Communication & Participation**
- Instructor values active engagement; students should prepare thoughtful responses to prompts
- Questions are encouraged; conceptual clarity prevents downstream misunderstandings
- Group work requires clear role definition and coordinated effort

---

## Follow-Up Actions for Students

### Before Next Session
- [ ] Read introduction materials from Week 1 to strengthen understanding of software engineering economic benefits
- [ ] Review the four core process activities until they can be articulated fluently
- [ ] Finalize project group formation and topic selection
- [ ] Begin component analysis for your selected project
- [ ] Identify which process model (Waterfall, Incremental, Spiral, or RUP) best fits your project

### During Next Session
- [ ] Submit project topics and full group member lists
- [ ] Prepare short description of project goals and software objectives
- [ ] Apply Waterfall, Incremental, and Spiral model perspectives to your project
- [ ] Attend coordinated campus visit to resolve library access issues

### Skills Development
- [ ] Familiarize yourself with Figma or alternative UI/UX design tools
- [ ] Ensure your team includes members with UI/UX design capability
- [ ] Consider the AI-in-Research training if relevant to your proposal
- [ ] Practice entity-relationship (ER) modeling for database design

---

## Summary

The CMP 722 Software Engineering Principles course establishes a rigorous foundation in software process models and practical application to student projects. Dr. Oluwasefunmi Arogundade emphasizes that mastery of the four core process activities—specification, design/implementation, validation, and evolution—is non-negotiable. Different development models (Waterfall, Incremental, Spiral, RUP) provide alternative sequencing and iteration strategies for these activities, each suited to different project contexts.

Key takeaways include:

1. **Process activities are universal; models are flexible**—All software systems pass through the same four activities, but the path differs by model
2. **Reuse is the industry standard**—Component-based development with careful requirement alignment reduces cost and leverages proven solutions
3. **Prototyping and incremental delivery reduce risk**—Early customer feedback and prioritized feature delivery minimize rework and project failure
4. **Risk management is explicit**—Especially in Spiral and RUP models, risk assessment at every phase prevents catastrophic failures
5. **Design is multifaceted**—Architecture, database, UI/UX, and components are distinct deliverables requiring specialized attention

Students are expected to apply these concepts to their course projects, demonstrating competency in model selection, requirement engineering, and design across all four dimensions.

---

**Document Prepared:** Based on CMP 722 Recap (June 3) and Transcripts (June 3 & June 10, 2026)  
**Status:** Ready for student review and project application
